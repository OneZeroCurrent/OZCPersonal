//元素对象
let photo = document.querySelector(".photo");
let items = document.querySelectorAll(".photo > img");
let left = document.querySelector(".last");
let right = document.querySelector(".next");

let index = 0;
let time;

function position(){
    photo.style.left = (index * -1000)+"px"
}

function add(){
    if(index >= items.length-1){
        index = 0;
    }else{
        index++;
    }
}

function desc(){
    if(index < 1){
        index = items.length;
    }else{
        index--;
    }
}

function timer(){
    time = setInterval(()=>{
        index++
        desc()
        add()
        position()
    },2000)
}

left.addEventListener('click',()=>{
    desc();
    position();
    clearInterval(time);
    timer()
})

right.addEventListener('click',()=>{
    add();
    position();
    clearInterval(time);
    timer()
})

timer();